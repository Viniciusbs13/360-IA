import { useEffect, useRef, useState } from 'react';
import { gsap, EASE, reduceMotion, scrollTo } from '@/lib/motion';
import { nav, site } from '@/data/content';
import { Mark } from './Loader';

export default function Nav({ visible }: { visible: boolean }) {
  const [open, setOpen] = useState(false);
  const list = useRef<HTMLUListElement>(null);
  const root = useRef<HTMLElement>(null);

  useEffect(() => {
    if (!visible || !root.current || reduceMotion()) return;
    gsap.from(root.current.querySelectorAll('.nv'), { opacity: 0, y: -10, duration: 1, ease: EASE, stagger: 0.06, delay: 0.3 });
  }, [visible]);

  useEffect(() => {
    const el = list.current;
    if (!el) return;
    const items = el.querySelectorAll('li');
    if (reduceMotion()) { el.style.display = open ? 'block' : 'none'; return; }
    if (open) {
      el.style.display = 'block';
      gsap.fromTo(items, { opacity: 0, y: -8 }, { opacity: 1, y: 0, duration: 0.6, ease: EASE, stagger: 0.04 });
    } else {
      gsap.to(items, { opacity: 0, y: -6, duration: 0.25, ease: 'power2.in', stagger: 0.02, onComplete: () => { el.style.display = 'none'; } });
    }
  }, [open]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const go = (href: string) => { setOpen(false); scrollTo(href); };

  return (
    <header ref={root} className={`fixed inset-x-0 top-0 z-50 transition-opacity duration-700 ${visible ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
      <div className="flex items-center justify-between px-5 py-5 sm:px-8">
        <a href="#inicio" onClick={(e) => { e.preventDefault(); go('#inicio'); }} className="nv inline-flex items-center gap-2 o-95" aria-label={site.brand}>
          <Mark className="h-7 w-7" />
        </a>
        <div className="flex items-center gap-6 sm:gap-8">
          <span className="nv t-label hidden items-center gap-2 sm:inline-flex o-95"><span className="h-1.5 w-1.5 rounded-full bg-ok shadow-[0_0_10px_#2ecc40]" /> {site.status}</span>
          <div className="relative">
            <button type="button" onClick={() => setOpen((v) => !v)} aria-expanded={open} aria-controls="site-menu" className="nv flex h-9 w-9 items-center justify-center" aria-label="Menu">
              <span className="flex gap-1">
                <i className="h-1 w-1 rounded-full bg-fg" /><i className="h-1 w-1 rounded-full bg-fg" /><i className="h-1 w-1 rounded-full bg-fg" />
              </span>
            </button>
            <ul id="site-menu" ref={list} style={{ display: 'none' }} className="absolute right-0 top-full mt-3 min-w-[180px] border-t border-white/20 pt-3 text-right">
              {nav.map((n) => (
                <li key={n.href} className="py-1">
                  <a href={n.href} onClick={(e) => { e.preventDefault(); go(n.href); }} className="t-label text-[0.95rem] o-95 hover:text-accent transition-colors">{n.label}</a>
                </li>
              ))}
              <li className="py-1 pt-3"><span className="t-micro o-55">{site.domain}</span></li>
            </ul>
          </div>
        </div>
      </div>
    </header>
  );
}
