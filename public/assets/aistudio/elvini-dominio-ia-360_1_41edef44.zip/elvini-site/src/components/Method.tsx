import { method, site, includes } from '@/data/content';
import Reveal, { Fade } from './ui/Reveal';
import { scrollTo } from '@/lib/motion';

/* Painel branco arredondado inset sobre o preto, com grade editorial,
   marcas de registro, lista numerada e marquee — padrão da página de projeto. */
export default function Method() {
  const marquee = Array.from({ length: 10 }, () => [site.product, method.year]).flat();
  return (
    <section id="metodo" className="relative z-10 px-3 py-6 sm:px-6 sm:py-10">
      <div className="relative overflow-hidden rounded-[24px] bg-panel text-[#111] shadow-[0_60px_120px_-40px_rgba(0,0,0,0.9)]">
        <span className="reg left-8 top-8" /><span className="reg right-8 top-8" /><span className="reg bottom-8 left-8" /><span className="reg bottom-8 right-8" />

        {/* header */}
        <div className="flex items-center justify-between px-6 pt-10 sm:px-12 sm:pt-14">
          <h2 className="t-display text-[2rem] leading-none sm:text-[3.6rem]">{site.product}</h2>
          <span className="t-label hidden sm:inline-flex items-center gap-3 text-[#111]/80">{method.kicker} <Crosshair /></span>
        </div>

        {/* hero band: image-like block with grid */}
        <div className="mx-6 mt-8 grid overflow-hidden rounded-md border border-black/10 sm:mx-12 lg:grid-cols-[1fr_260px]">
          <div className="relative" style={{ backgroundImage: 'linear-gradient(to right, rgba(0,0,0,0.06) 1px, transparent 1px), linear-gradient(to bottom, rgba(0,0,0,0.06) 1px, transparent 1px), linear-gradient(135deg,#eceef1,#f8f8f6)', backgroundSize: '48px 48px, 48px 48px, 100% 100%' }}>
            <div className="flex min-h-[260px] items-center justify-center p-5 sm:p-8">
              <ChatMock />
            </div>
          </div>
          <div className="flex flex-col justify-between border-t border-black/10 p-5 lg:border-l lg:border-t-0">
            <div className="t-label text-[#111]/55 space-y-1"><div>Aula</div><div>Exercício</div><div>Aplicação</div></div>
            <a href="#modulos" onClick={(e) => { e.preventDefault(); scrollTo('#modulos'); }} className="u-link t-label self-end text-[#111]/70">Ver módulos <span className="arrow" aria-hidden="true">↘</span></a>
          </div>
        </div>

        {/* editorial grid */}
        <div className="grid gap-10 px-6 py-12 sm:px-12 lg:grid-cols-[120px_1fr] lg:gap-16">
          <span className="t-display text-2xl text-[#111]/80">{method.year}</span>
          <div className="lg:ml-auto lg:max-w-[560px] lg:text-right">
            <Reveal as="h3" className="t-display-md text-[1.6rem] sm:text-[2rem]">{method.title}</Reveal>
            <Fade><p className="mt-5 text-[1rem] leading-relaxed text-[#111]/70">{method.body}</p></Fade>
          </div>
        </div>

        <div className="grid gap-10 px-6 pb-12 sm:px-12 lg:grid-cols-2 lg:gap-16">
          <div>
            <Reveal as="h3" className="t-display text-[2.4rem] leading-none sm:text-[3.4rem]">{method.roleTitle}</Reveal>
            <Fade><p className="mt-4 max-w-[52ch] text-[0.95rem] leading-relaxed text-[#111]/65">{method.roleBody}</p></Fade>
            <div className="mt-10">
              <p className="t-label text-[#111]/55">{method.stackTitle}</p>
              <ol className="mt-3 border-l border-black/15 pl-6">
                {method.stack.map((s, i) => (
                  <li key={s} className="py-2">
                    <span className="t-label block text-[#111]/45">{String(i + 1).padStart(2, '0')}</span>
                    <span className="t-label text-base text-[#111]/85">{s}</span>
                  </li>
                ))}
              </ol>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 self-start">
            {includes.map((it) => (
              <Fade key={it.t} className="rounded-md border border-black/10 bg-white/60 p-5">
                <span className="t-display t-mono-num block text-[2.6rem] leading-none">{it.n}</span>
                <span className="t-label mt-2 block text-[#111]/85">{it.t}</span>
                <span className="mt-1 block text-sm text-[#111]/55">{it.d}</span>
              </Fade>
            ))}
          </div>
        </div>

        {/* marquee */}
        <div className="marquee border-y border-black/10 py-3 text-[#111]/55">
          <div className="marquee-track t-label">
            {[...marquee, ...marquee].map((t, i) => <span key={i} className="inline-flex items-center gap-10">{t} <i className="h-1 w-1 rounded-full bg-current" /></span>)}
          </div>
        </div>

        {/* constraints */}
        <div className="relative px-6 py-16 text-center sm:px-12 sm:py-24">
          <span className="reg left-[12%] top-10" /><span className="reg right-[12%] top-10" /><span className="reg bottom-10 left-[12%]" /><span className="reg bottom-10 right-[12%]" />
          <Reveal as="h3" className="t-display-md mx-auto text-[1.8rem] sm:text-[2.4rem]">{method.constraintsTitle}</Reveal>
          <Fade><p className="mx-auto mt-5 max-w-[60ch] text-[0.95rem] leading-relaxed text-[#111]/65">{method.constraints}</p></Fade>
          <div className="mt-10 flex flex-col items-center">
            <a href="#oferta" onClick={(e) => { e.preventDefault(); scrollTo('#oferta'); }} className="pill pill-dark">Ver a oferta <span className="arrow" aria-hidden="true">→</span></a>
            <span className="mt-1 h-10 w-px border-l border-dashed border-black/40" aria-hidden="true" />
            <i className="h-1.5 w-1.5 rounded-full bg-black/60" aria-hidden="true" />
          </div>
        </div>
      </div>
    </section>
  );
}

function Crosshair() {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6 opacity-50" fill="none" stroke="currentColor" strokeWidth="1" aria-hidden="true">
      <circle cx="12" cy="12" r="7" /><path d="M12 1v6M12 17v6M1 12h6M17 12h6" />
    </svg>
  );
}

function ChatMock() {
  return (
    <div className="w-full max-w-[520px] rounded-xl border border-black/10 bg-white/85 p-4 text-left shadow-[0_30px_60px_-30px_rgba(0,0,0,0.35)] backdrop-blur">
      <div className="t-micro flex items-center justify-between text-[#111]/45"><span>Sua IA · ChatGPT, Claude ou Gemini</span><span>Aula 02</span></div>
      <div className="mt-3 ml-auto max-w-[88%] rounded-xl rounded-br-sm bg-[#111] px-3 py-2 text-[0.82rem] leading-snug text-white/90">
        <span className="t-micro block text-accent">Você</span>
        Você é analista comercial. Com os dados abaixo, escreva o relatório semanal pro diretor: 5 linhas, começa pelo resultado, termina com 2 próximos passos.
      </div>
      <div className="mt-2 max-w-[92%] rounded-xl rounded-bl-sm border border-black/10 bg-white px-3 py-2 text-[0.82rem] leading-snug text-[#111]/80">
        <span className="t-micro block text-[#111]/45">IA</span>
        <b>Semana 42:</b> faturamento R$ 184 mil (+9% vs. semana anterior), puxado pela região Sul. Conversão caiu de 14% para 12% no canal WhatsApp. Estoque do item A-12 cobre 6 dias. <b>Próximos passos:</b> 1) revisar o roteiro do WhatsApp; 2) repor o A-12 até quinta.
      </div>
    </div>
  );
}
