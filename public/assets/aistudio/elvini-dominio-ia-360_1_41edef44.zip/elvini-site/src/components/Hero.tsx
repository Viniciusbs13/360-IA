import { useEffect, useRef } from 'react';
import { gsap, ScrollTrigger, EASE, reduceMotion, scrollTo } from '@/lib/motion';
import { hero, statements, site } from '@/data/content';
import Reveal from './ui/Reveal';

/* #hero-zone = 1 tela de hero + 1 tela pinada de frases. A cena 3D lê o
   progresso dessa zona para inclinar o portal e aproximar a câmera. */
export default function Hero({ active }: { active: boolean }) {
  const heroRef = useRef<HTMLElement>(null);
  const stRef = useRef<HTMLElement>(null);

  // entrance
  useEffect(() => {
    if (!active || !heroRef.current || reduceMotion()) return;
    const q = heroRef.current.querySelectorAll('.hv');
    gsap.fromTo(q, { opacity: 0, y: 18 }, { opacity: 1, y: 0, duration: 1.2, ease: EASE, stagger: 0.08, delay: 0.5 });
  }, [active]);

  // statements: pinned, one at a time
  useEffect(() => {
    const el = stRef.current;
    if (!el) return;
    const lines = el.querySelectorAll<HTMLElement>('.stmt');
    if (reduceMotion()) { lines.forEach((l) => (l.style.opacity = '1')); return; }
    const tl = gsap.timeline({
      scrollTrigger: { trigger: el, start: 'top top', end: `+=${lines.length * 70}%`, pin: true, scrub: 0.8, anticipatePin: 1 },
    });
    lines.forEach((l, i) => {
      tl.fromTo(l, { opacity: 0, y: 30, filter: 'blur(8px)' }, { opacity: 1, y: 0, filter: 'blur(0px)', duration: 1, ease: 'power2.out' }, i * 1.6);
      if (i < lines.length - 1) tl.to(l, { opacity: 0, y: -24, filter: 'blur(6px)', duration: 0.8, ease: 'power2.in' }, i * 1.6 + 1.1);
    });
    return () => { tl.scrollTrigger?.kill(); tl.kill(); };
  }, []);

  // hero fades out as you scroll past it
  useEffect(() => {
    const el = heroRef.current;
    if (!el || reduceMotion()) return;
    const st = gsap.to(el.querySelector('.hero-inner'), {
      opacity: 0, y: -40, ease: 'none',
      scrollTrigger: { trigger: el, start: 'top top', end: 'bottom 40%', scrub: true },
    });
    return () => { st.scrollTrigger?.kill(); st.kill(); };
  }, []);

  return (
    <div id="hero-zone" className="relative z-10">
      <section id="inicio" ref={heroRef} className="relative flex min-h-[100svh] flex-col justify-end px-5 pb-10 pt-28 sm:px-8 sm:pb-12">
        <div className="hero-inner grid gap-8 lg:grid-cols-[1fr_auto] lg:items-end">
          <div className="max-w-[1100px]">
            <p className="hv t-micro text-accent mb-5">{hero.eyebrow}</p>
            <h2 className="hv t-display text-[15vw] sm:text-[10vw] lg:text-[6.6rem] xl:text-[7.6rem]">
              <span className="block">{hero.title[0]}</span>
              <span className="block text-accent">{hero.title[1]}</span>
            </h2>
            <p className="hv mt-6 max-w-[48ch] text-[1.02rem] leading-relaxed o-85 sm:text-lg">{hero.sub}</p>
            <div className="hv mt-7 flex flex-wrap items-center gap-5">
              <a href={site.checkoutUrl} onClick={(e) => { if (site.checkoutUrl.startsWith('#')) { e.preventDefault(); scrollTo(site.checkoutUrl); } }} className="pill pill-accent">{hero.cta} <span className="arrow" aria-hidden="true">→</span></a>
              <a href="#modulos" onClick={(e) => { e.preventDefault(); scrollTo('#modulos'); }} className="u-link t-label o-85">Ver os módulos <span className="arrow" aria-hidden="true">↘</span></a>
            </div>
          </div>
          <div className="hv flex items-end justify-between gap-6 lg:flex-col lg:items-end lg:gap-2">
            <span className="t-label o-55 inline-flex items-center gap-2">{hero.scroll} <span aria-hidden="true">↓</span></span>
            <span className="t-display t-mono-num text-3xl leading-none o-95">{site.product}</span>
          </div>
        </div>
      </section>

      <section ref={stRef} className="relative flex min-h-[100svh] items-center justify-center px-5 text-center" aria-label="Manifesto">
        <div className="relative h-[60vh] w-full max-w-[1000px]">
          {statements.map((s, i) => (
            <p key={i} className="stmt stmt-text absolute inset-x-0 top-1/2 -translate-y-1/2 t-display-md text-[2.2rem] leading-[1] sm:text-[3.6rem] lg:text-[4.6rem]" style={{ opacity: 0 }}>
              {i === statements.length - 1 ? <span className="text-accent">{s}</span> : renderHl(s)}
            </p>
          ))}
        </div>
        <span className="absolute bottom-8 left-5 sm:left-8 t-micro o-35">{String(1).padStart(2, '0')} / {String(statements.length).padStart(2, '0')}</span>
      </section>

      {/* lead-in for the next section */}
      <div className="px-5 pb-24 pt-10 sm:px-8">
        <Reveal as="p" className="mx-auto max-w-[56ch] text-center text-lg o-55 sm:text-xl">Vamos te ensinar a usar IA do básico ao avançado, pra você usar no seu dia a dia, produzir mais e ganhar dinheiro com isso.</Reveal>
      </div>
    </div>
  );
}

/** '[[trecho]]' vira <span class="hl-dark"> (destaque escuro, legível sobre o disco claro) */
function renderHl(s: string) {
  return s.split(/(\[\[.*?\]\])/g).map((part, i) =>
    part.startsWith('[[') ? <span key={i} className="hl-dark">{part.slice(2, -2)}</span> : <span key={i}>{part}</span>,
  );
}

export { ScrollTrigger };
