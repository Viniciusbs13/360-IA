import { useEffect, useRef, useState } from 'react';
import { gsap, ScrollTrigger, reduceMotion } from '@/lib/motion';
import { modules } from '@/data/content';
import Reveal from './ui/Reveal';

/* Carrossel horizontal pinado (padrão "projects"): um módulo por tela,
   contador 01 / 08 e "próximo módulo" no canto inferior direito. */
export default function Modules() {
  const wrap = useRef<HTMLElement>(null);
  const track = useRef<HTMLDivElement>(null);
  const [idx, setIdx] = useState(0);
  const stRef = useRef<ScrollTrigger | null>(null);

  useEffect(() => {
    const w = wrap.current, t = track.current;
    if (!w || !t) return;
    const mm = gsap.matchMedia();
    mm.add('(min-width: 1024px) and (prefers-reduced-motion: no-preference)', () => {
      const n = modules.length;
      const tween = gsap.to(t, {
        x: () => -(t.scrollWidth - window.innerWidth), ease: 'none',
        scrollTrigger: {
          trigger: w, start: 'top top', end: () => `+=${t.scrollWidth - window.innerWidth}`, pin: true, scrub: 0.6, anticipatePin: 1, invalidateOnRefresh: true,
          onUpdate: (self) => setIdx(Math.min(n - 1, Math.round(self.progress * (n - 1)))),
        },
      });
      stRef.current = tween.scrollTrigger ?? null;
      // parallax on the big numbers
      t.querySelectorAll<HTMLElement>('.mod-num').forEach((el) => {
        gsap.fromTo(el, { xPercent: 20 }, { xPercent: -20, ease: 'none', scrollTrigger: { trigger: el, containerAnimation: tween, start: 'left right', end: 'right left', scrub: true } });
      });
      return () => { tween.scrollTrigger?.kill(); tween.kill(); stRef.current = null; };
    });
    return () => mm.revert();
  }, []);

  const next = () => {
    const st = stRef.current;
    if (!st) { document.getElementById(`mod-${Math.min(modules.length - 1, idx + 1)}`)?.scrollIntoView({ behavior: 'smooth' }); return; }
    const n = modules.length;
    const target = Math.min(n - 1, idx + 1) / (n - 1);
    const y = st.start + (st.end - st.start) * target;
    const lenis = (window as unknown as { __lenis?: { scrollTo: (v: number, o?: object) => void } }).__lenis;
    lenis ? lenis.scrollTo(y, { duration: 1.2 }) : window.scrollTo({ top: y, behavior: 'smooth' });
  };

  return (
    <section id="modulos" ref={wrap} className="relative z-10 bg-bg/60 backdrop-blur-[2px] lg:h-[100svh] lg:overflow-hidden">
      <div className="px-5 pt-20 sm:px-8 lg:absolute lg:inset-x-0 lg:top-0 lg:z-20 lg:pt-24">
        <p className="t-micro text-accent">O que você vai aprender</p>
        <Reveal as="h2" className="t-display-md mt-3 text-[2rem] sm:text-[2.8rem] lg:text-[2.4rem]">8 módulos, do zero ao seu sistema de IA.</Reveal>
      </div>

      <div ref={track} className="flex flex-col gap-12 px-5 py-16 sm:px-8 lg:h-full lg:flex-row lg:items-end lg:gap-0 lg:py-0 lg:pb-24 lg:pt-48">
        {modules.map((m, i) => (
          <article id={`mod-${i}`} key={m.n} className="relative flex shrink-0 flex-col justify-end lg:h-full lg:w-[64vw] lg:pr-[10vw] xl:w-[56vw]">
            <span className="mod-num pointer-events-none select-none t-display t-mono-num absolute -top-6 left-0 text-[7rem] leading-none text-white/[0.05] lg:top-6 lg:text-[18rem]" aria-hidden="true">{m.n}</span>
            <div className="relative">
              <div className="flex items-baseline gap-4">
                <span className="t-display t-mono-num text-accent text-xl">{m.n}</span>
                <span className="t-micro o-55">{m.dur}</span>
              </div>
              <h3 className="t-display mt-3 text-[3.2rem] leading-[0.9] sm:text-[4.6rem] lg:text-[5.6rem]">{m.title}</h3>
              <p className="t-label mt-3 text-base o-95">{m.sub}</p>
              <p className="mt-4 max-w-[46ch] text-[0.98rem] leading-relaxed o-55">{m.desc}</p>
              <ul className="mt-5 flex flex-wrap gap-2">
                {m.stack.map((s) => <li key={s} className="t-micro rounded-full border border-white/15 px-3 py-1.5 o-85">{s}</li>)}
              </ul>
            </div>
          </article>
        ))}
      </div>

      <div className="hidden lg:flex absolute bottom-8 right-8 z-20 flex-col items-end gap-1">
        <span className="t-display t-mono-num text-3xl leading-none"><span className="o-95">{String(idx + 1).padStart(2, '0')}</span> <span className="text-base o-55">/ {String(modules.length).padStart(2, '0')}</span></span>
        <button type="button" onClick={next} className="u-link t-label text-[0.75rem] o-85"><span aria-hidden="true">›</span> Próximo módulo</button>
      </div>
      <span className="hidden lg:block absolute bottom-8 left-8 z-20 t-micro o-35">Role para percorrer</span>
    </section>
  );
}
