import { useState } from 'react';
import logo from '@/assets/dominio-ia-360-logo.jpg';
import { offer, site, faq, footer } from '@/data/content';
import Reveal, { Fade } from './ui/Reveal';
import { Mark } from './Loader';
import { scrollTo } from '@/lib/motion';

export function Offer() {
  const external = !site.checkoutUrl.startsWith('#');
  return (
    <section id="oferta" className="relative z-10 px-5 py-28 sm:px-8">
      <div className="mx-auto grid max-w-[1120px] gap-12 lg:grid-cols-[1fr_420px] lg:items-end">
        <div>
          <p className="t-micro text-accent">{offer.kicker}</p>
          <Reveal as="h2" className="t-display mt-4 text-[2.6rem] leading-[0.9] sm:text-[4rem] lg:text-[4.6rem]">{offer.title}</Reveal>
          <ul className="mt-10 grid gap-3 sm:grid-cols-2">
            {offer.list.map((l) => (
              <li key={l} className="flex gap-3 border-t border-white/10 pt-3 text-[0.95rem] o-85"><span className="text-accent-2" aria-hidden="true">✓</span>{l}</li>
            ))}
          </ul>
        </div>

        <Fade className="relative rounded-[20px] border border-white/15 bg-bg/80 p-7 backdrop-blur sm:p-8">
          <span className="reg right-4 top-4 text-fg" />
          <img src={logo} alt={site.product} className="mx-auto h-28 w-auto rounded-md object-cover object-top opacity-90" />
          <div className="mt-5 text-center">
            <span className="t-label block o-55">{site.product}</span>
            <div className="mt-3 flex items-start justify-center gap-1 leading-none"><span className="t-display mt-2 text-xl text-accent">R$</span><span className="t-display t-mono-num text-[5.2rem] leading-[0.85]">{site.price.now}</span></div>
            <div className="t-label mt-1 o-85">{site.price.installments}</div>
          </div>
          <a href={site.checkoutUrl} target={external ? '_blank' : undefined} rel={external ? 'noopener' : undefined} onClick={(e) => { if (!external) { e.preventDefault(); scrollTo('#oferta'); } }} className="pill pill-accent mt-6 w-full justify-center">{offer.cta} <span className="arrow" aria-hidden="true">→</span></a>
          <p className="mt-4 text-center text-xs leading-relaxed o-55">{offer.pay}</p>
          <p className="mt-4 border-t border-dashed border-white/20 pt-4 text-center text-xs leading-relaxed o-85">{offer.guarantee}</p>
        </Fade>
      </div>
    </section>
  );
}

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="relative z-10 px-5 py-20 sm:px-8">
      <div className="mx-auto max-w-[820px]">
        <p className="t-micro text-accent">Dúvidas</p>
        <Reveal as="h2" className="t-display-md mt-3 text-[2rem] sm:text-[2.8rem]">Respostas sem rodeio.</Reveal>
        <div className="mt-8 border-t border-white/10">
          {faq.map((f, i) => {
            const isOpen = open === i;
            return (
              <div key={f.q} className="border-b border-white/10">
                <button type="button" onClick={() => setOpen(isOpen ? null : i)} aria-expanded={isOpen} className="flex w-full items-center justify-between gap-6 py-5 text-left">
                  <span className="t-label text-[0.95rem] o-95">{f.q}</span>
                  <span className={`t-display text-xl text-accent transition-transform duration-500 ${isOpen ? 'rotate-45' : ''}`} aria-hidden="true">+</span>
                </button>
                <div className="grid transition-[grid-template-rows] duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]" style={{ gridTemplateRows: isOpen ? '1fr' : '0fr' }}>
                  <div className="overflow-hidden"><p className="max-w-[64ch] pb-6 text-[0.95rem] leading-relaxed o-55">{f.a}</p></div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export function Contact() {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try { await navigator.clipboard.writeText(site.email); setCopied(true); setTimeout(() => setCopied(false), 1600); } catch { /* ignore */ }
  };
  const external = !site.checkoutUrl.startsWith('#');
  return (
    <section className="relative z-10 flex min-h-[90svh] flex-col justify-end px-5 pb-8 pt-24 sm:px-8" aria-label="Fechamento">
      <div className="grid gap-10 lg:grid-cols-2 lg:items-end">
        <div>
          <Reveal as="h2" className="t-display text-[3.6rem] leading-[0.88] sm:text-[6rem] lg:text-[7.4rem]">Bora fazer algo foda?</Reveal>
          <a href={site.checkoutUrl} target={external ? '_blank' : undefined} rel={external ? 'noopener' : undefined} onClick={(e) => { if (!external) { e.preventDefault(); scrollTo('#oferta'); } }} className="pill pill-accent mt-8">{offer.cta} <span className="arrow" aria-hidden="true">→</span></a>
        </div>
        <div className="lg:text-right">
          <p className="t-display-md text-[2rem] sm:text-[2.6rem]">Fale com a gente</p>
          <button type="button" onClick={copy} className="u-link t-label mt-2 o-85" aria-live="polite">{copied ? 'E-mail copiado' : site.email} <span className="arrow" aria-hidden="true">↙</span></button>
        </div>
      </div>

      <footer className="mt-16 flex flex-col gap-4 border-t border-white/10 pt-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3 t-micro o-55">
          <Mark className="h-5 w-5" /> <span>{site.domain} · {site.year}</span>
          <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-fg">{footer.legal}</a>
          <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-fg">{footer.privacy}</a>
        </div>
        <p className="max-w-[60ch] t-micro normal-case tracking-normal o-35 sm:text-right">{footer.note}</p>
      </footer>
    </section>
  );
}
