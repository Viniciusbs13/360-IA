# Notas de motion (aplicadas a partir das skills de referência)

Fontes: greensock/gsap-skills (gsap-react, gsap-scrolltrigger, gsap-timeline), LottieFiles/motion-design-skill, img2threejs.

## Personalidade escolhida: Premium
- Duração: 350–600 ms para entradas de cards/blocos; 600–1200 ms só para reveals dramáticos (hero, frases no scroll).
- Easing de assinatura: `expo.out` (entradas) / `power2.in` (saídas). Sem overshoot.
- Stagger total < 500 ms: palavras 30 ms, cards 70–100 ms.
- Três camadas sempre: primária (texto/cards), secundária (linhas do HUD, chips), ambiente (buraco negro, poeira, marquee).

## Regras GSAP seguidas
- `gsap.registerPlugin(ScrollTrigger)` uma vez (`src/lib/motion.ts`).
- ScrollTriggers criados de cima para baixo; `ScrollTrigger.refresh()` após o loader sair.
- Scroll horizontal dos módulos com `ease: 'none'` + `containerAnimation` para os números em paralaxe.
- `scrub` OU `toggleActions`, nunca os dois no mesmo trigger.
- Cleanup em todo `useEffect` (kill de tweens/triggers); guardas contra o double-run do StrictMode no typewriter.
- Lenis sincronizado com `ScrollTrigger.update` via `gsap.ticker`.

## Pendente / possível evolução
- Trocar os `useEffect` por `useGSAP` (`@gsap/react`) quando o pacote entrar no AI Studio.
- img2threejs: usar para gerar um relevo 3D do logo "Domínio IA 360°" e colocá-lo dentro da moldura do HUD (hoje é imagem 2D com paralaxe).
