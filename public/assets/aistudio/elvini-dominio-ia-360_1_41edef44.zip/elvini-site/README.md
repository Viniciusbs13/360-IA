# ELVINI · Domínio IA 360°

Site de vendas do curso **Domínio IA 360°**, construído no padrão visual e de motion do aengel.io (ver `ANALISE_AENGEL.md`), com identidade ELVINI (preto profundo, League Spartan + Manrope, acento dourado/ciano do logo).

Stack: Vite 7 · React 19 · TypeScript · Tailwind v4 · GSAP + ScrollTrigger · Lenis · Three.js (react-three-fiber). Mesma base dos apps do Google AI Studio.

## Rodar

```bash
npm install
npm run dev      # http://localhost:3000
npm run build    # gera dist/
npm run lint     # tsc --noEmit
```

## Levar para o Google AI Studio

1. Suba esta pasta num repositório GitHub (sem `node_modules` e `dist`).
2. No AI Studio → Build → caixa de prompt → **+** → **Import from GitHub** → escolha o repositório.
3. O AI Studio instala as dependências e abre o preview. `metadata.json` já está no formato esperado.

## Onde editar

| O quê | Arquivo |
|---|---|
| Todo o texto (títulos, módulos, oferta, FAQ, preço, e-mail, link do checkout) | `src/data/content.ts` |
| Cores, fontes, tokens | `src/index.css` (`@theme`) |
| Cena 3D (portal de partículas) | `src/components/Scene.tsx` |
| Loader de abertura | `src/components/Loader.tsx` |
| Hero + frases no scroll | `src/components/Hero.tsx` |
| Carrossel de módulos | `src/components/Modules.tsx` |
| Painel branco (método) | `src/components/Method.tsx` |
| Quem ensina (HUD) | `src/components/About.tsx` |
| Oferta, FAQ, fechamento, rodapé | `src/components/Offer.tsx` |
| Logo do produto | `src/assets/dominio-ia-360-logo.jpg` (trocar pelo PNG original em alta) |

## Pendências (placeholders em `src/data/content.ts`)

- `site.checkoutUrl` — colar o link real do checkout (hoje aponta para `#oferta`).
- `site.email` — e-mail de contato real.
- `about.name` e `about.body` — nome e bio do instrutor; foto no lugar do logo em `About.tsx`.
- Números do curso (+15 ferramentas e skills, 1 aula ao vivo por mês, +100 prompts, 12 meses, certificado) — confirmar o que será entregue.
- Páginas "Aviso legal" e "Privacidade" do rodapé ainda não existem.
- `site.status` ("Turma aberta") — trocar quando fechar a turma.

## Estrutura da página

Loader → Hero (cena 3D) → 5 frases no scroll → Carrossel de 8 módulos (horizontal, pinado) → Painel branco do método (grade editorial, lista numerada, marquee, "o que não é") → Quem ensina (typewriter + HUD) → Oferta (R$ 47) → FAQ → Fechamento + rodapé.
