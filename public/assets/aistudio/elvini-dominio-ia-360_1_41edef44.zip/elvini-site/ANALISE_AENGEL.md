
## 7. About — detalhe quadro a quadro (2ª análise, 2026-10-20)
- O HUD inteiro é desenhado no canvas (não há DOM para os labels), por isso a inspeção de código não ajuda; a análise é visual.
- Headline: digitada letra a letra; o cursor é um **bloco segmentado** (3 barrinhas empilhadas) na cor de acento, não uma barra fina. Sem reflow do texto.
- Cada caixa/etiqueta tem um **readout numérico** pequeno embaixo ("6.7581", "-91.23", "0.000, 0.000"), em fonte miúda, parte em acento.
- Linhas: saem dos **cantos** das caixas para os **cantos** da moldura central; **pontos** nas duas extremidades.
- A moldura central acompanha o objeto 3D; o objeto (e o HUD) tem **paralaxe de mouse** sutil.
- Labels em minúsculas com "●" na ponta; relógio + coordenadas centralizados no rodapé.
- Tudo entra junto: linhas se traçam, labels aparecem com stagger curto.
